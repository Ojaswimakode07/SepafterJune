"""SepafterJune server: serves the site, the song catalog, uploads, the /admintome song editor and the contact-form email."""
from email.message import EmailMessage
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import base64, getpass, hmac, json, mimetypes, os, re, secrets, smtplib, ssl, sys, time
from pathlib import Path
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parent
ENV_FILE = ROOT / ".env"
DATA_DIR = Path(os.environ.get("DATA_DIR", str(ROOT / "data"))).resolve()
DATA_DIR.mkdir(parents=True, exist_ok=True)
(DATA_DIR / "uploads").mkdir(parents=True, exist_ok=True)
# Seed the catalog once when persistent storage is empty. Uploaded media remains on DATA_DIR.
if not (DATA_DIR / "song_catalog.json").exists() and (ROOT / "song_catalog.json").exists():
    (DATA_DIR / "song_catalog.json").write_text((ROOT / "song_catalog.json").read_text(encoding="utf-8"), encoding="utf-8")
STYLES = {"rings", "duo", "aurora", "fish", "birds", "flowers", "stars", "clouds", "butterflies", "leaves", "moon", "ocean", "sunset", "garden", "rain", "confetti", "music"}
HEX = re.compile(r"#[0-9a-fA-F]{6}")
FILE_URL = re.compile(r"(/uploads/[a-f0-9]{32}\.[a-z0-9]{3,4})?")


def env(name, default=""):
    return os.environ.get(name, default).strip()


def load_env():
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                key, value = line.split("=", 1)
                os.environ[key.strip()] = value.strip().strip('"').strip("'")


def setup():
    print("\nFirst-time setup. You answer these once; they are saved in the .env file in this folder.\n")
    while True:
        pw = getpass.getpass("Choose an owner password for the song editor (12+ characters, hidden): ")
        if len(pw) >= 12 and pw == getpass.getpass("Type it again: "):
            break
        print("Too short or the two did not match. Try again.")
    gmail = input("Gmail address that sends the emails: ").strip()
    app = getpass.getpass("Google App Password (16 letters, hidden): ").replace(" ", "")
    to = input(f"Email address that should receive fan messages [{gmail}]: ").strip() or gmail
    lines = [f"EDITOR_PASSWORD={pw}", "SMTP_HOST=smtp.gmail.com", "SMTP_PORT=587", f"SMTP_USER={gmail}",
             f"SMTP_PASSWORD={app}", f"MAIL_TO={to}", f"MAIL_FROM={gmail}", "PORT=8010"]
    ENV_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("Saved. To change anything later, run:  python server.py --setup\n")


def clean(value, limit):
    return re.sub(r"[<>]", "", value)[:limit] if isinstance(value, str) else None


class Handler(BaseHTTPRequestHandler):
    server_version = "SepafterJune/2.0"
    catalog_path, inbox_path, upload_dir = DATA_DIR / "song_catalog.json", DATA_DIR / "messages.jsonl", DATA_DIR / "uploads"
    sessions, hits = {}, {}

    # ---------- helpers ----------
    def reply(self, status, payload=None):
        data = b"" if status == 204 else json.dumps(payload).encode("utf-8")
        self.send_response(status)
        for k, v in (("Access-Control-Allow-Origin", "*"), ("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS"),
                     ("Access-Control-Allow-Headers", "Content-Type, Authorization"), ("Cache-Control", "no-store")):
            self.send_header(k, v)
        if data:
            self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def limited(self, bucket, limit, window):
        key, now = (bucket, self.client_address[0]), time.time()
        recent = [t for t in self.hits.get(key, []) if now - t < window]
        recent.append(now)
        self.hits[key] = recent
        return len(recent) > limit

    def read_json(self, max_size=24_000_000):
        size = int(self.headers.get("Content-Length", "0"))
        if size <= 0 or size > max_size:
            raise OverflowError("too large")
        value = json.loads(self.rfile.read(size))
        if not isinstance(value, dict):
            raise ValueError("expected object")
        return value

    def is_editor(self):
        auth = self.headers.get("Authorization", "")
        token = auth[7:] if auth.startswith("Bearer ") else ""
        if self.sessions.get(token, 0) < time.time():
            self.sessions.pop(token, None)
            return False
        return True

    def read_catalog(self):
        try:
            data = json.loads(self.catalog_path.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except (OSError, json.JSONDecodeError):
            return []

    def save_catalog(self, catalog):
        tmp = self.catalog_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(catalog, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.catalog_path)

    def send_file(self, path, content_type):
        try:
            size = path.stat().st_size
        except OSError:
            return self.reply(404, {"success": False, "message": "Not found"})
        start, end, status = 0, size - 1, 200
        wanted = re.fullmatch(r"bytes=(\d*)-(\d*)", self.headers.get("Range", "").strip())
        if wanted and size:  # byte ranges let the browser jump to any moment of a song
            first, last = wanted.groups()
            if first == "" and last != "":
                start = max(0, size - int(last))
            elif first != "":
                start = int(first)
                end = min(int(last), size - 1) if last else size - 1
            if start > end or start >= size:
                self.send_response(416)
                self.send_header("Content-Range", f"bytes */{size}")
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            status = 206
        try:
            with path.open("rb") as f:
                f.seek(start)
                data = f.read(end - start + 1)
        except OSError:
            return self.reply(404, {"success": False, "message": "Not found"})
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Accept-Ranges", "bytes")
        if status == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(data)

    def deny(self):
        self.reply(401, {"success": False, "message": "Please sign in as the site owner."})

    # ---------- routes ----------
    def do_OPTIONS(self):
        self.reply(204)

    def do_GET(self):
        path = unquote(self.path.split("?", 1)[0])
        if path == "/health":
            return self.reply(200, {"ok": True})
        if path == "/api/songs":
            return self.reply(200, {"success": True, "songs": [s for s in self.read_catalog() if s.get("live", True)]})
        if path in ("/api/admin/songs", "/api/messages"):
            if not self.is_editor():
                return self.deny()
            if path == "/api/admin/songs":
                return self.reply(200, {"success": True, "songs": self.read_catalog()})
            try:
                rows = [json.loads(l) for l in self.inbox_path.read_text(encoding="utf-8").splitlines() if l.strip()]
            except OSError:
                rows = []
            return self.reply(200, {"success": True, "messages": rows[-100:][::-1]})
        if path == "/admintome":
            return self.send_file(ROOT / "admin.html", "text/html; charset=utf-8")
        if path in ("/", "/index.html"):
            return self.send_file(ROOT / "index.html", "text/html; charset=utf-8")
        if path.startswith("/uploads/"):
            name = Path(path).name
            if re.fullmatch(r"[a-f0-9]{32}\.(?:png|jpg|jpeg|webp|gif|mp3|m4a|wav|ogg|mp4|webm)", name):
                return self.send_file(self.upload_dir / name, mimetypes.guess_type(name)[0] or "application/octet-stream")
        self.reply(404, {"success": False, "message": "Not found"})

    def do_DELETE(self):
        if not self.is_editor():
            return self.deny()
        match = re.fullmatch(r"/api/songs/([a-f0-9]{32})", self.path)
        if not match:
            return self.reply(404, {"success": False, "message": "Not found"})
        catalog = [s for s in self.read_catalog() if s.get("id") != match.group(1)]
        self.save_catalog(catalog)
        self.reply(200, {"success": True, "songs": catalog})

    def do_POST(self):
        if self.path == "/api/login":
            return self.login()
        if self.path == "/api/contact":
            return self.contact()
        if not self.is_editor():
            return self.deny()
        if self.path == "/api/upload":
            return self.upload()
        if self.path == "/api/songs":
            return self.upsert_song()
        self.reply(404, {"success": False, "message": "Not found"})

    def login(self):
        configured = env("EDITOR_PASSWORD")
        if not configured:
            return self.reply(503, {"success": False, "message": "Editor password is not set. Run: python server.py --setup"})
        if self.limited("login", 8, 600):
            return self.reply(429, {"success": False, "message": "Too many attempts. Wait 10 minutes."})
        try:
            password = str(self.read_json(8_000).get("password", ""))
        except (ValueError, OverflowError):
            return self.reply(400, {"success": False, "message": "Invalid sign-in request."})
        if not hmac.compare_digest(password.encode(), configured.encode()):
            return self.reply(401, {"success": False, "message": "Password did not match."})
        token = secrets.token_urlsafe(32)
        self.sessions[token] = time.time() + 12 * 3600
        self.reply(200, {"success": True, "token": token})

    def upload(self):
        allowed = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp", "image/gif": ".gif", "audio/mpeg": ".mp3",
                   "audio/mp3": ".mp3", "audio/mp4": ".m4a", "audio/x-m4a": ".m4a", "audio/wav": ".wav", "audio/x-wav": ".wav",
                   "audio/ogg": ".ogg", "video/mp4": ".mp4", "video/webm": ".webm"}
        try:
            data = self.read_json()
            mime = str(data.get("mime", ""))
            if mime not in allowed:
                return self.reply(415, {"success": False, "message": "Use a JPG/PNG/WebP image or an MP3/M4A/WAV/OGG audio file."})
            raw = base64.b64decode(str(data.get("data", "")), validate=True)
            if not raw or len(raw) > 18_000_000:
                return self.reply(413, {"success": False, "message": "Each upload must be under 18 MB."})
            name = secrets.token_hex(16) + allowed[mime]
            self.upload_dir.mkdir(exist_ok=True)
            (self.upload_dir / name).write_bytes(raw)
            self.reply(200, {"success": True, "url": "/uploads/" + name})
        except (ValueError, OverflowError):
            self.reply(400, {"success": False, "message": "Invalid upload."})

    def upsert_song(self):
        bad = lambda msg: self.reply(400, {"success": False, "message": msg})
        try:
            raw = self.read_json(64_000)
        except (ValueError, OverflowError):
            return bad("Invalid song data.")
        song = {}
        for key, limit in (("t", 120), ("big", 100), ("m", 100), ("d", 500), ("tick", 200), ("lyrics", 40_000)):
            song[key] = clean(raw.get(key, ""), limit)
            if song[key] is None:
                return bad("A song field is invalid.")
        for key in ("audio", "cover", "full"):
            value = raw.get(key, "")
            if not isinstance(value, str) or not FILE_URL.fullmatch(value):
                return bad("Audio, full song and cover must be files uploaded through the editor.")
            song[key] = value
        timings = raw.get("sync", [])
        if not (isinstance(timings, list) and len(timings) <= 2000 and all(
                x is None or (isinstance(x, (int, float)) and not isinstance(x, bool) and 0 <= x <= 7200) for x in timings)):
            return bad("Lyric timings look wrong. Paste the numbers exactly as the sync tool gave them.")
        song["sync"] = [None if x is None else round(float(x), 2) for x in timings]
        video = raw.get("video", "")
        if not isinstance(video, str) or not re.fullmatch(r"[A-Za-z0-9_-]{0,20}", video):
            return bad("YouTube ID looks wrong. Use only the ID, not the full link.")
        song["video"] = video
        if not song["t"].strip() or not song["big"].strip():
            return bad("A song title and a large display title are required.")
        pal = raw.get("pal")
        if not (isinstance(pal, dict) and HEX.fullmatch(str(pal.get("bg", ""))) and HEX.fullmatch(str(pal.get("paper", "")))
                and isinstance(pal.get("rings"), list) and len(pal["rings"]) == 5 and all(HEX.fullmatch(str(c)) for c in pal["rings"])):
            return bad("Choose valid colours.")
        song["pal"] = {"bg": pal["bg"], "paper": pal["paper"], "rings": [str(c) for c in pal["rings"]]}
        song["style"] = raw.get("style") if raw.get("style") in STYLES else "rings"
        song["live"] = raw.get("live") is not False
        sid = str(raw.get("id") or "")
        song["id"] = sid if re.fullmatch(r"[a-f0-9]{32}", sid) else secrets.token_hex(16)
        catalog = self.read_catalog()
        index = next((i for i, s in enumerate(catalog) if s.get("id") == song["id"]), None)
        catalog.append(song) if index is None else catalog.__setitem__(index, song)
        self.save_catalog(catalog)
        self.reply(200, {"success": True, "song": song, "songs": catalog})

    def contact(self):
        try:
            data = self.read_json(32_000)
        except (ValueError, OverflowError):
            return self.reply(400, {"success": False, "message": "Invalid form data."})
        if str(data.get("_honeypot", "")).strip():
            return self.reply(200, {"success": True})
        if self.limited("contact", 5, 600):
            return self.reply(429, {"success": False, "message": "Too many messages just now. Please try again in a few minutes."})
        name, sender = str(data.get("name", "")).strip()[:120], str(data.get("email", "")).strip()[:254]
        body = str(data.get("message", "")).strip()[:12_000]
        subject = re.sub(r"[\r\n]+", " ", str(data.get("subject", "Message from SepafterJune")))[:180]
        if not name or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]{2,}", sender) or not body:
            return self.reply(400, {"success": False, "message": "Please check your name, email, and message."})
        emailed = self.send_mail(name, sender, subject, body)
        record = {"time": time.strftime("%Y-%m-%d %H:%M"), "name": name, "email": sender, "subject": subject, "message": body, "emailed": emailed}
        try:  # every message is kept in messages.jsonl, so nothing is lost even if email fails
            with self.inbox_path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
        except OSError:
            if not emailed:
                return self.reply(502, {"success": False, "message": "Your message could not be saved. Please try again."})
        self.reply(200, {"success": True, "emailed": emailed})

    def send_mail(self, name, sender, subject, body):
        host, user, password, to = env("SMTP_HOST"), env("SMTP_USER"), env("SMTP_PASSWORD").replace(" ", ""), env("MAIL_TO")
        if not all((host, user, password, to)):
            print("Email is not set up (missing SMTP settings in .env). Run: python server.py --setup", flush=True)
            return False
        mail = EmailMessage()
        mail["Subject"], mail["From"], mail["To"], mail["Reply-To"] = subject, env("MAIL_FROM") or user, to, sender
        mail.set_content(f"From: {name} <{sender}>\n\n{body}")
        try:
            port = int(env("SMTP_PORT", "587"))
            if port == 465:
                with smtplib.SMTP_SSL(host, port, context=ssl.create_default_context(), timeout=20) as smtp:
                    smtp.login(user, password); smtp.send_message(mail)
            else:
                with smtplib.SMTP(host, port, timeout=20) as smtp:
                    smtp.ehlo(); smtp.starttls(context=ssl.create_default_context()); smtp.ehlo()
                    smtp.login(user, password); smtp.send_message(mail)
            return True
        except (OSError, smtplib.SMTPException, ValueError) as exc:
            print(f"Email delivery failed: {exc}", flush=True)
            if isinstance(exc, smtplib.SMTPAuthenticationError):
                print("  -> Gmail refused the login. Use a 16-letter App Password (not your normal password), "
                      "with 2-Step Verification on. Fix it with: python server.py --setup", flush=True)
            return False

    def log_message(self, fmt, *args):
        print(f"{self.address_string()} - {fmt % args}", flush=True)


if __name__ == "__main__":
    if "--setup" in sys.argv or (not ENV_FILE.exists() and not env("EDITOR_PASSWORD")):
        setup()
    load_env()
    if "--test-email" in sys.argv:  # python server.py --test-email  -> sends one test mail and says why if it fails
        ok = Handler.send_mail(Handler.__new__(Handler), "Test", env("MAIL_TO") or env("SMTP_USER"), "SepafterJune email test", "If you can read this, email works.")
        print("\nEmail test: SENT. Check your inbox (and Spam)." if ok else "\nEmail test: FAILED. Read the message above.")
        sys.exit(0 if ok else 1)
    host, port = env("HOST", "127.0.0.1"), int(env("PORT", "8010"))
    print(f"\nSepafterJune is running.\n  Website:      http://127.0.0.1:{port}\n  Song editor:  http://127.0.0.1:{port}/admintome\nKeep this window open. Press Ctrl+C to stop.\n", flush=True)
    ThreadingHTTPServer((host, port), Handler).serve_forever()
