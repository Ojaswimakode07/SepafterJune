# SepafterJune — deployment-ready

## Local
1. Keep your real `.env` beside `server.py` (never commit it).
2. Run `start.bat` or `python server.py`.
3. Public site: `http://127.0.0.1:8010/`
4. Owner editor: `http://127.0.0.1:8010/admintome`

## Production
This repository includes `render.yaml` for a Python web service. It uses a persistent disk because the editor writes the song catalog, fan messages, and uploaded media to disk.

Set these secrets in the host dashboard:
- `EDITOR_PASSWORD`
- `SMTP_USER`
- `SMTP_PASSWORD`
- `MAIL_TO`
- `MAIL_FROM`

The public URL is `/`. The owner editor is `/admintome` and requires the owner password before any admin API can be used.

## Important
The current upload directory is not included in this deployment package because the uploaded binary media files were not supplied with the project files. After deployment, sign in at `/admintome` and upload/replace the audio and cover files you want to keep on the persistent disk.

Do not upload or commit `.env`.
